package com.android.launcher2;


import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class BootBroadcastReceiver extends BroadcastReceiver {
   
	private static String TAG = "LauncherBootBroadcastReceiver";
    @Override
    public void onReceive(Context context, Intent intent) 
    {
        String action = intent.getAction().toString();
        Log.e(TAG,"wwz start:"+ action);
        if ("android.intent.action.BOOT_COMPLETED".equals(action)) 
        {
        	Log.w(TAG, "wwz: BOOT_COMPLETED ");
        	String packageName = "";
        	String className = "";
        	/*if(!Launcher.recordForStartAppPackageName.equals("") && !Launcher.recordForStartAppClassName.equals(""))
        	{
        		packageName = Launcher.recordForStartAppPackageName;
        		className = Launcher.recordForStartAppClassName;
        	}
        	else 
       		{
            	packageName =LauncherIconReplace.fm_start_pakagename;
        		className = LauncherIconReplace.fm_start_classname;
            }
        	
        	try 
    		{
    			ComponentName componet = new ComponentName(packageName, className);
    			Intent i = new Intent();
    			i.setComponent(componet);
    			i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    			context.startActivity(i);
    		} 
    		catch (Exception e) 
    		{
    			
    			 Log.e(TAG, "wwz packageName "+ packageName +" not_found");
    			
    		}*/
        } 
    }
    
}
