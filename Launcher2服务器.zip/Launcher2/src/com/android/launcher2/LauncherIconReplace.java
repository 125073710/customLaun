package com.android.launcher2;

import com.android.launcher.R;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;


public class LauncherIconReplace {

	private static int i_fm = R.drawable.fm;
	private static int i_fm_press = R.drawable.fm_p;
	
    private static int i_bluetooth = R.drawable.bluetooth;
    private static int i_bluetooth_press = R.drawable.bluetooth_p;
    
    private static int i_allapp = R.drawable.allapp;
    private static int i_allapp_press = R.drawable.allapp_p;
    
    private static int i_muisc = R.drawable.music;
    private static int i_muisc_press = R.drawable.music_p;
    
    private static int i_daohang = R.drawable.daohang;
    private static int i_daohang_press = R.drawable.daohang_p;
    
    public static String allapp_start_pakagename = "com.gps_test";
    public static String allapp_start_classname =  "com.gps_test.MainActivity";
    
    public static String daohang_start_pakagename = "com.android.settings";
    public static String daohang_start_classname =  "com.android.settings.Settings";
    
    public static String fm_start_pakagename = "com.tricheer.radio";
    public static String fm_start_classname =  "com.tricheer.radio.MainActivity";
  
    public static String skip_pakagename = "com.chartcross.gpstestplus";
    public static String skip_classname =  "com.chartcross.gpstestplus.GPSTestPlus";


	//for one app two function
	public static String mv_app_pakagename = 	 "com.tricheer.player";
    public static String video_app_classname =  "com.tricheer.player.VideoPlayerActivity";
	public static String music_app_classname =  "com.tricheer.player.MusicPlayerActivity";
   
    private static String TAG = "LauncherIconTheme";

    public static Bitmap  getIconBitmap(Context context , String packageName , String className) 
    {
        Resources resources = context.getResources();
        int iconId = getIconId(packageName, className,0);
        if (iconId != -1)
        {
            return BitmapFactory.decodeResource(resources, iconId);
        }
        return null;
    }
      
    public static Drawable getIconDrawable(Context context , String packageName , String className) 
    {
        Resources resources = context.getResources();
        int iconId = getIconId(packageName, className,0);
        if ( iconId != -1) 
        {
            return resources.getDrawable(iconId);
        }
        return null;
    }
    
    public static Drawable getIconDrawableForPress(Context context , String packageName , String className) 
    {
        Resources resources = context.getResources();
        int iconId = getIconId(packageName, className,1);
        if ( iconId != -1) 
        {
            return resources.getDrawable(iconId);
        }
        return null;
    }
     
    private static int getIconId(String packageName , String className ,int tag)
    {
    	
    	if (fm_start_pakagename.equals(packageName) && fm_start_classname.equals(className)) 
        {
    		if(tag == 1)
        	{
        		return  i_fm_press;
        	}
            return i_fm;
        }
    	
        if ( "com.tricheer.bluetoothcarkit".equals(packageName)&& "com.tricheer.bluetoothcarkit.MainActivity".equals(className)) 
        {
        	if(tag == 1)
        	{
        		return  i_bluetooth_press;
        	}
            return i_bluetooth;

        }
        else if (allapp_start_pakagename.equals(packageName) &&allapp_start_classname.equals(className)) 
        {
        	if(tag == 1)
        	{
        		return  i_allapp_press;
        	}
            return i_allapp;
        }
        else if (daohang_start_pakagename.equals(packageName) && daohang_start_classname.equals(className)) 
        {
        	if(tag == 1)
        	{
        		return  i_daohang_press;
        	}
            return i_daohang;
        }
        
        else if ("com.tricheer.player".equals(packageName) && "com.tricheer.player.MusicPlayerActivity".equals(className)) 
        {
        	if(tag == 1)
        	{
        		return  i_muisc_press;
        	}
            return i_muisc;
        }
        else
        {
        	return -1;
        }
    
    }

	public static String getIconCustomName(Context context , String packageName , String className) 
    {
		Log.e(TAG, "wwz: "+"packagename = " + packageName + " classname" +className);

		if (allapp_start_pakagename.equals(packageName) &&allapp_start_classname.equals(className)) 
		{
			return context.getResources().getString(R.string.icon_custom_name_alapp);
		}
		else if (daohang_start_pakagename.equals(packageName) && daohang_start_classname.equals(className)) 
        {
            return context.getResources().getString(R.string.icon_custom_name_daohang);
        }
		else
		{
			Log.e(TAG, "wwz: not find package name and class name.");
			return "";
		}
    }
}
